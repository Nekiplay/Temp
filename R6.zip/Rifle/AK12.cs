//using System.Windows.Forms;

MCC.LoadPlugin(new AK12());

//Script Extensions

public class AK12 : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
    private void New()
    {
        if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
        {
            for (int i = 0; i < 20; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 4);
                    MouseMove(-1, 0);
                    Sleep(25);
                }
                else { break; }
            }
            for (int i = 0; i < 2; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 4);
                    MouseMove(0, 0);
                    Sleep(25);
                }
                else { break; }
            }
            for (int i = 0; i < 45; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 4);
                    MouseMove(-1, 0);
                    Sleep(25);
                }
                else { break; }
            }
            for (int i = 0; i < 15; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    MouseMove(-1, 0);
                    Sleep(25);
                }
                else { break; }
            }
        }
    }
    public override void Update()
    {
        New();
    }
}