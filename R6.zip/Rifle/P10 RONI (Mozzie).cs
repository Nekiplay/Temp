//using System.Windows.Forms;

MCC.LoadPlugin(new P10RONI());

//Script Extensions

public class P10RONI : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
		else if (s.GetType() == typeof(string))
        {
			UnLoadPlugin();
		}
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
    private void New()
    {
        if (IsKeyPressed(Keys.LButton) && IsKeyPressed(keys))
        {
            for (int i = 0; i < 20; i++)
            {
                if (IsKeyPressed(Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 8);
                    MouseMove(0, 0);
                    Sleep(18);
                }
                else { break; }
            }
        }
    }
    public override void Update()
    {
        New();
    }
}