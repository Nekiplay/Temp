//using System.Windows.Forms;

MCC.LoadPlugin(new _417());

//Script Extensions

public class _417 : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
    private void New()
    {
        if (IsKeyPressed(Keys.RButton) && IsKeyPressed(keys))
        {
            if (IsKeyPressed(Keys.RButton) && IsKeyPressed(keys))
            {
                LeftDown();
                Sleep(16);
                LeftUp();
                MouseMove(0, 2);
                MouseMove(0, 0);
                Sleep(12);
            }
        }
    }
    public override void Update()
    {
        New();
    }
}