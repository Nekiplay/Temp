//using System.Windows.Forms;

MCC.LoadPlugin(new T5SMG());

//Script Extensions

public class T5SMG : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
			Console.WriteLine(key);
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
		else if (s.GetType() == typeof(string))
        {
			UnLoadPlugin();
		}
    }
	public override void Initialize()
    {
		PluginPostObject("Включен");
    }
    private void New()
    {
        if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
        {
            for (int i = 0; i < 10; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 8);
                    MouseMove(0, 0);
                    Sleep(25);
                }
                else { break; }
            }
        }
    }
    public override void Update()
    {
        New();
    }
}