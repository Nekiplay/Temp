//using System.Windows.Forms;

MCC.LoadPlugin(new Mk_14_EBR());

//Script Extensions

public class Mk_14_EBR : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
    private void New()
    {
        if (IsKeyPressed(System.Windows.Forms.Keys.RButton) && IsKeyPressed(keys))
        {
            if (IsKeyPressed(Keys.RButton) && IsKeyPressed(keys))
            {
                LeftDown();
                Sleep(16);
                LeftUp();
                MouseMove(0, 9);
                MouseMove(-2, 0);
                Sleep(25);
            }
        }
    }
    public override void Update()
    {
        New();
    }
}