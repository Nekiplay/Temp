//using System.Windows.Forms;

MCC.LoadPlugin(new _556XI());

//Script Extensions

public class _556XI : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
		else if (s.GetType() == typeof(string))
        {
			UnLoadPlugin();
		}
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
    private void New()
    {
        if (IsKeyPressed(Keys.LButton) && IsKeyPressed(keys))
        {
            for (int i = 0; i < 25; i++)
            {
                if (IsKeyPressed(Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 6);
                    MouseMove(0, 0);
                    Sleep(25);
                }
                else { break; }
            }
            for (int i = 0; i < 5; i++)
            {
                if (IsKeyPressed(Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    MouseMove(1, 0);
                    Sleep(25);
                }
                else { break; }
            }
        }
    }
    public override void Update()
    {
        New();
    }
}