//using System.Windows.Forms;

MCC.LoadPlugin(new ScorpionEvo());

//Script Extensions

public class ScorpionEvo : Plugin
{
    private Keys keys = Keys.LButton;
    public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
    private void New()
    {
        if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
        {
            for (int i = 0; i < 10; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    Sleep(15);
                    MouseMove(2, 0);
                    Sleep(10);
                }
                else { break; }
            }
            for (int i = 0; i < 10; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    Sleep(15);
                    MouseMove(-2, 0);
                    Sleep(10);
                }
                else { break; }
            }
            for (int i = 0; i < 10; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    Sleep(15);
                    MouseMove(2, 0);
                    Sleep(10);
                }
                else { break; }
            }
            for (int i = 0; i < 10; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    Sleep(15);
                    MouseMove(-2, 0);
                    Sleep(10);
                }
                else { break; }
            }
            for (int i = 0; i < 70; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 6);
                    Sleep(15);
                    MouseMove(5, 0);
                    Sleep(10);
                }
                else { break; }
            }
            for (int i = 0; i < 10; i++)
            {
                if (IsKeyPressed(System.Windows.Forms.Keys.LButton) && IsKeyPressed(keys))
                {
                    MouseMove(0, 5);
                    Sleep(15);
                    MouseMove(-2, 0);
                    Sleep(10);
                }
                else { break; }
            }
        }
    }
    public override void Update()
    {
        New();
    }
}