//using System.Windows.Forms;

MCC.LoadPlugin(new D50());

//Script Extensions

public class D50 : Plugin
{
    private Keys keys = Keys.RButton;
    private void New()
    {
        if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
        {
            if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
            {
				LeftDown();
                Sleep(15);
                LeftUp();
                MouseMove(0, 20);
                Sleep(12);
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
	public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.RButton;
            }
            else
            {
                this.keys = key;
            }
        }
		else if (s.GetType() == typeof(string))
        {
			UnLoadPlugin();
		}
    }
    public override void Update()
    {
        New();
    }
}