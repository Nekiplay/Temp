//using System.Windows.Forms;

MCC.LoadPlugin(new RMM());

//Script Extensions

public class RMM : Plugin
{
    private Keys keys = Keys.LButton;
    private void New()
    {
        if (IsKeyPressed(keys) && IsKeyPressed(Keys.LButton))
        {
            if (IsKeyPressed(keys) && IsKeyPressed(Keys.LButton))
            {
                MouseMove(0, 11);
                Sleep(25);
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
	public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
		else if (s.GetType() == typeof(string))
        {
			UnLoadPlugin();
		}
    }
    public override void Update()
    {
        New();
    }
}