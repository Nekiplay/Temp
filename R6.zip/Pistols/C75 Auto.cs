//using System.Windows.Forms;

MCC.LoadPlugin(new C75_Auto());

//Script Extensions

public class C75_Auto : Plugin
{
    private Keys keys = Keys.RButton;
    private void New()
    {
        if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
        {
            if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
            {
                LeftDown();
                Sleep(15);
                LeftUp();
                MouseMove(0, 11);
                Sleep(25);
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
	public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
			Console.WriteLine(key);
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
    public override void Update()
    {
        New();
    }
}