//using System.Windows.Forms;

MCC.LoadPlugin(new GSH_18());

//Script Extensions

public class GSH_18 : Plugin
{
    private Keys keys = Keys.RButton;
    private void New()
    {
        if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
        {
            for (int i = 0; i < 15; i++)
            {
                if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
                {
                    LeftDown();
                    Sleep(15);
                    LeftUp();
                    MouseMove(0, 4);
                    Sleep(25);
                }
                else { break; }
            }
            for (int i = 0; i < 4; i++)
            {
                if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
                {
                    LeftDown();
                    Sleep(15);
                    LeftUp();
                    MouseMove(0, 6);
                    Sleep(25);
                }
                else { break; }
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
	public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
    public override void Update()
    {
        New();
    }
}