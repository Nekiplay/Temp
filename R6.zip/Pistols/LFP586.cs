//using System.Windows.Forms;

MCC.LoadPlugin(new LFP586());

//Script Extensions

public class LFP586 : Plugin
{
    private Keys keys = Keys.RButton;
    private void New()
    {
        if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
        {
            if (IsKeyPressed(keys) && IsKeyPressed(Keys.RButton))
            {
                LeftDown();
                Sleep(15);
                LeftUp();
                MouseMove(0, 22);
                Sleep(25);
            }
        }
    }
	public override void Initialize()
    {
		PluginPostObject(null);
    }
	public override void ReceivedObject(object s)
    {
        if (s.GetType() == typeof(Keys))
        {
            Keys key = (Keys)s;
            if (key == Keys.None)
            {
                this.keys = Keys.LButton;
            }
            else
            {
                this.keys = key;
            }
        }
    }
    public override void Update()
    {
        New();
    }
}